# Pacman 吃豆游戏

- 项目演示(DEMO)地址：https://passer-by.com/pacman/

### 版权
本游戏由 [passer-by.com](https://passer-by.com/) 制作，请尊重作者，引用请注明来源。

功能

- [x] 地图绘制
- [x] 玩家控制
- [x] NPC根据玩家坐标实时自动寻径
- [x] 吃豆积分系统
- [x] 能量豆功能
- [x] 多关卡(共12关)
- [ ] 特殊物品记分
